This is an update of the [Adafruit VS1053 Library](https://github.com/adafruit/Adafruit_VS1053_Library) for ESP32 with Interrupt support

It's currently not fully tested!
